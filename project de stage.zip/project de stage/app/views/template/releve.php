<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Favicon-->
      <link rel="icon" type="image/x-icon" href="<?= ASSETS ?>/assets/favicon.ico" />
    <link rel="stylesheet" href="<?= ASSETS ?>/css/bootstrap/bootstrap.min.css">
    <title><?= WEBSITE_NAME . ' | ' . $data['page_title'] ?></title>

    <link rel="stylesheet" href="<?= ASSETS ?>/css/releve.css">
</head>

<body>

    <?php
    auth_check();
    if (isset($_SESSION['username'])) : ?>
        <p class="wlcm-msg"> Bienvenue sur <?= $_SESSION['username'];  ?> Administrateur !</p>

    <?php endif; ?>

    <div class="logout">
        <a class="btn btn-primary" href="logout">Log out</a>
    </div>

    <marquee direction="left">
        <p>Administrateur choisissez la formation d'ont vous voulez consultez les informations des étudiants !</p>
    </marquee>

    <div class="txt-container">


        <a href="Gratuite_releve">
            <p class="formation">Formation Gratuite</p>
        </a>


        <a href="Bureautique_releve">
            <p class="formation">Formation Productivite en Enterprise</p>
        </a>

        <a href="Technique_releve">
            <p class="formation">Formation Technique</p>
        </a>

    </div>

</body>

</html>