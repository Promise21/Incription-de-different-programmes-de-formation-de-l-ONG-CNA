<?php
//router it loads all the classes in core
require "app/core/config.php";
require "app/core/Database.php";
require "app/core/Controller.php";
require "app/core/function.php";
require "app/core/app.php";
require "app/core/auth_check.php";
require "app/core/Routeur.php";
